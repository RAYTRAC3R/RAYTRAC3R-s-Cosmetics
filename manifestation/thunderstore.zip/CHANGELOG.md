0.4.7
- Added more plumage hairs
- Added heartchest pattern for Possum.

0.4.6
- DO NOT BOOT THE GAME WITH THE PREVIOUS VERSION it'll corrupt your save :sob: this has been fixed

0.4.5
- HOPEFULLY fixed thunderstore upload of mod (i accidentally uploaded 0.4.3 a second time)

0.4.4
- Added Slit eyes
- Fixed several Minty eye color variants not showing up
- Hid a few eyecolors that are fairly redundant (may be restored behind a toggle in the future)
- Fixed Hyena skin no longer working on Dogbat head

0.4.3
- Cleaned up code a small amount
- Added a TON of eye color variants for Ring eyes
- Added a few eye color variants for Minty eyes
- Added support for Stitches pattern (from SpookMod) on Batdog

0.4.2
- Added Penguin sounds, sourced from:
https://freesound.org/people/iamaviolin/sounds/463033/
https://freesound.org/people/Breviceps/sounds/705839/
https://freesound.org/people/Owen_Garcia/sounds/719110/

0.4.1
- Fixed export options to no longer export base game assets
- Changed Batdog head patterns for Calico, Spotty, and Tux base game patterns
- Added pattern compatibility for Batdog with modded Clown and Hyena patterns

0.4.0
- Adjusted eyepatch for Penguin
- Changed Collie head pattern for Dogbat
- Added 'Minty', 'Ankha', and 'Audie' eyes.

0.3.3
- Added mod info metadata
- Added Plumage hairs in black, pink, red, yellow, green, and blue.
- Adjusted round glasses on Penguin!

0.3.2
- Added unique icons for most items!
- Fixed textures to no longer be blurry
- Cigarette and Scarab Mask now compatible with Penguins
- Removed several extra files in the release zip, should be a bit smaller now.

0.3.1
- Added Baby Hair accessory
- Added (WIP!) Penguin head

0.3.0
- Added Scarab mask
- Added Silver fur color

0.2.0
- Added Batdog head (based on my fursona Minty)
- Added Mint primary and secondary colors

0.1.0
- Added Dib Ghost shirt
- Added Chest Heart pattern
- Added Color Ring eye set