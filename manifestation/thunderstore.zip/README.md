A cosmetics pack for WEBFISHING, uses Lure to implement!
- 1 new shirt
- around 40 new eyes (5 not counting color variants)
- 1 new pattern
- 3 new species heads
- 2 new fur colors
- 12 new accessories (3 not counting color variants)