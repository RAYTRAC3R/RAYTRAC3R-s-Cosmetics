A cosmetics pack for WEBFISHING, uses Lure to implement!
- 1 new shirt
- around 40 new eyes (5 not counting color variants)
- 3 new patterns
- 3 new species heads
- 2 new fur colors
- over 30 new accessories (5 not counting color variants)

Feel free to include this mod in let's plays or mod showcases (with credit!)